# Project Structure
## Human-Readable Guide

---

## Swift package layout

```
cirunner/
├── Package.swift
├── Sources/
│   ├── CIRunner/                    ← Main executable target
│   │   ├── main.swift               ← Entry point, argument parsing
│   │   ├── Orchestrator.swift       ← Top-level coordinator, ties everything together
│   │   └── Commands/
│   │       ├── RunCommand.swift     ← `cirunner run` — starts the daemon
│   │       └── SetupCommand.swift   ← `cirunner setup-base-image`
│   │
│   ├── Core/                        ← Library target, no framework deps
│   │   ├── Models/
│   │   │   ├── Job.swift            ← JobDescriptor, JobState, JobID
│   │   │   ├── Config.swift         ← AppConfig and sub-configs
│   │   │   └── RunnerEnv.swift      ← Token payload written to VirtioFS share
│   │   ├── Scheduling/
│   │   │   └── JobScheduler.swift   ← Central actor
│   │   ├── Logging/
│   │   │   └── Logger.swift         ← swift-log setup, file backend
│   │   └── Errors/
│   │       └── CIRunnerError.swift  ← Error types
│   │
│   ├── GitHubClient/                ← Library target
│   │   ├── GitHubClient.swift       ← Actor, polling, registration
│   │   ├── GitHubAuth.swift         ← JWT generation, token refresh
│   │   └── GitHubModels.swift       ← API response types (Codable)
│   │
│   ├── VMManager/                   ← Library target (macOS only)
│   │   ├── VMManager.swift          ← Actor, VM lifecycle
│   │   ├── VMConfiguration.swift    ← VZVirtualMachineConfiguration builder
│   │   ├── APFSCloner.swift         ← clonefile() wrapper
│   │   └── BaseImageSetup.swift     ← One-time base image creation
│   │
│   └── ContainerManager/            ← Library target (macOS 26+ only)
│       ├── ContainerManager.swift   ← Actor, container lifecycle
│       └── ContainerConfiguration.swift
│
└── Tests/
    ├── CoreTests/
    ├── GitHubClientTests/
    └── VMManagerTests/
```

---

## Package.swift

```swift
// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "cirunner",
    platforms: [
        .macOS(.v15)
    ],
    products: [
        .executable(name: "cirunner", targets: ["CIRunner"]),
    ],
    dependencies: [
        // CLI argument parsing
        .package(
            url: "https://github.com/apple/swift-argument-parser",
            from: "1.3.0"
        ),
        // Logging
        .package(
            url: "https://github.com/apple/swift-log",
            from: "1.5.0"
        ),
        // JWT for GitHub App auth
        .package(
            url: "https://github.com/vapor/jwt-kit",
            from: "5.0.0"
        ),
        // YAML config parsing
        .package(
            url: "https://github.com/jpsim/Yams",
            from: "5.0.0"
        ),
        // Database (job history, audit log)
        .package(
            url: "https://github.com/groue/GRDB.swift",
            from: "6.0.0"
        ),
    ],
    targets: [
        .executableTarget(
            name: "CIRunner",
            dependencies: [
                "Core",
                "GitHubClient",
                "VMManager",
                "ContainerManager",
                .product(name: "ArgumentParser", package: "swift-argument-parser"),
                .product(name: "Logging", package: "swift-log"),
            ]
        ),
        .target(
            name: "Core",
            dependencies: [
                .product(name: "Logging", package: "swift-log"),
                .product(name: "Yams", package: "Yams"),
                .product(name: "GRDB", package: "GRDB.swift"),
            ]
        ),
        .target(
            name: "GitHubClient",
            dependencies: [
                "Core",
                .product(name: "JWTKit", package: "jwt-kit"),
                .product(name: "Logging", package: "swift-log"),
            ]
        ),
        .target(
            name: "VMManager",
            dependencies: [
                "Core",
                .product(name: "Logging", package: "swift-log"),
            ]
        ),
        .target(
            name: "ContainerManager",
            dependencies: [
                "Core",
                .product(name: "Logging", package: "swift-log"),
            ]
        ),
        .testTarget(name: "CoreTests", dependencies: ["Core"]),
        .testTarget(name: "GitHubClientTests", dependencies: ["GitHubClient"]),
        .testTarget(name: "VMManagerTests", dependencies: ["VMManager"]),
    ]
)
```

---

## Approved dependencies

| Package | Purpose | Why this one |
|---|---|---|
| `swift-argument-parser` | CLI subcommands (`run`, `setup-base-image`) | Apple-maintained, standard |
| `swift-log` | Structured logging with file backend | Apple-maintained, zero-overhead |
| `jwt-kit` | RS256 JWT for GitHub App auth | Vapor-maintained, well-tested |
| `Yams` | YAML config file parsing | Only good Swift YAML library |
| `GRDB.swift` | SQLite (job history, audit log) | Allows raw SQL, well-maintained |

**No other dependencies.** Do not add networking libraries (URLSession is sufficient), HTTP server libraries (no HTTP server needed), or database ORMs.

---

## Build and run

```bash
# Debug build
swift build

# Release build
swift build -c release

# Run (daemon mode)
.build/release/cirunner run --config ~/.cirunner/config.yaml

# One-time base image setup
.build/release/cirunner setup-base-image \
    --output ~/.cirunner/base-images/macos-xcode16.img

# Run tests
swift test
```

---

## Minimum deployment target

- **macOS 15** (Sequoia) for the core orchestrator and macOS VMs
- **macOS 26** (Tahoe) for Linux container support via Containerization framework

The `ContainerManager` target should use `#available(macOS 26, *)` guards throughout. The orchestrator should gracefully disable Linux container support when running on macOS 15.

---

## Swift Concurrency requirements

This project uses Swift 6 strict concurrency. `Package.swift` should set:

```swift
targets: [
    .target(
        name: "Core",
        swiftSettings: [
            .enableExperimentalFeature("StrictConcurrency")
        ]
    )
]
```

All mutable state must be inside actors. No `@unchecked Sendable` workarounds — fix the actual concurrency issue.
