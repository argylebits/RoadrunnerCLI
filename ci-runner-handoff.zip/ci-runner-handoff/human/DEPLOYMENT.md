# Deployment Models
## Human-Readable Guide

---

## The core constraint

`Virtualization.framework` needs an active **WindowServer session** to create and manage VMs. This is a hard technical constraint of the framework itself — not an Apple policy decision, not something that can be worked around with entitlements.

**What this means:** You cannot call `VZVirtualMachine.start()` from a process running as root with no logged-in user (a traditional Unix LaunchDaemon). The framework will fail at runtime.

This shapes everything about how the orchestrator is deployed.

---

## Option A — LaunchAgent with auto-login (recommended for MVP)

The orchestrator runs as a `LaunchAgent` under a dedicated `ci` user. The Mac is configured for automatic login to `ci` at boot.

### How it works

```
Machine boots
  → launchd starts system daemons (LaunchDaemons)
  → Auto-login kicks in for 'ci' user
  → WindowServer session starts for 'ci'
  → launchd loads ~/Library/LaunchAgents/ for 'ci' user
  → cirunner orchestrator starts
  → Virtualization.framework is now available (session exists)
  → Orchestrator begins polling GitHub
```

Nobody needs to be at the machine. The whole sequence is automatic.

### Installation steps

**1. Create a dedicated CI user**
```bash
sudo dscl . -create /Users/ci
sudo dscl . -create /Users/ci UserShell /bin/zsh
sudo dscl . -create /Users/ci RealName "CI Runner"
sudo dscl . -create /Users/ci UniqueID 503
sudo dscl . -create /Users/ci PrimaryGroupID 20
sudo dscl . -create /Users/ci NFSHomeDirectory /Users/ci
sudo createhomedir -c -u ci
```

**2. Enable auto-login**

System Settings → General → Login Options → Automatic login → select `ci`.

Or from Terminal:
```bash
sudo defaults write /Library/Preferences/com.apple.loginwindow autoLoginUser ci
```

**3. Disable sleep and screen lock for the ci session**
```bash
# Prevent display sleep
sudo pmset -a displaysleep 0
# Prevent system sleep
sudo pmset -a sleep 0
# Disable screen saver for ci user (run as ci user)
defaults -currentHost write com.apple.screensaver idleTime 0
```

**4. Install the orchestrator binary**
```bash
sudo cp .build/release/cirunner /usr/local/bin/cirunner
sudo chmod +x /usr/local/bin/cirunner
```

**5. Create config and log directories**
```bash
mkdir -p /Users/ci/.cirunner/logs
mkdir -p /Users/ci/.cirunner/base-images
cp config.yaml /Users/ci/.cirunner/config.yaml
```

**6. Install LaunchAgent plist**
```bash
cp com.cirunner.orchestrator.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.cirunner.orchestrator.plist
```

The plist file content is in `agent/LAUNCHAGENT_PLIST.xml`.

### Trade-offs

| | |
|---|---|
| ✅ Simple — one process, no IPC | ❌ Requires auto-login (session always active) |
| ✅ Same pattern as Cilicon, Tart, most Mac CI | ❌ FileVault requires manual password at reboot |
| ✅ Direct Virtualization.framework access | ❌ Session disruption if someone touches the machine |
| ✅ Easy to debug (single process) | ❌ Slightly larger attack surface than a root daemon |

### Who uses this pattern

- Cilicon
- Tart-based setups
- Buildkite Mac agents
- Most Mac CI providers running on bare metal

It is the industry-standard approach for this problem.

---

## Option B — Split daemon + LaunchAgent helper (advanced)

This approach separates the orchestration logic (which doesn't need a session) from the VM creation (which does) into two processes communicating over XPC.

```
LaunchDaemon: com.cirunner.daemon (root, no session)
  - GitHub polling
  - Job queue management
  - Logging
  - Configuration
  - Communicates with vmhelper over XPC

LaunchAgent: com.cirunner.vmhelper (ci user, needs session)
  - Receives XPC calls from daemon
  - All Virtualization.framework calls
  - Reports VM lifecycle events back to daemon
```

### Trade-offs

| | |
|---|---|
| ✅ Daemon survives lock screen and logout | ❌ Significantly more complex |
| ✅ Cleaner security boundary | ❌ XPC error handling is notoriously tricky |
| ✅ Proper Unix separation of concerns | ❌ Two binaries to build, sign, and distribute |
| ✅ Orchestration resilient to session disruption | ❌ Still requires auto-login for VMs to work |

**Important:** Even with Option B, you still need auto-login. The `vmhelper` LaunchAgent only runs when the `ci` user is logged in. The daemon survives a lock screen, but if no user session exists at all, `vmhelper` won't be running and VMs can't be created.

**Recommendation:** Implement Option A for MVP. Option B is only worth the complexity if you have a specific requirement for the orchestrator to survive user session disruption while still eventually creating VMs when the session resumes.

---

## FileVault considerations

FileVault (full-disk encryption) requires a password to be entered at boot before auto-login can proceed. This means:

- After a power outage or reboot, the machine sits at the FileVault unlock screen
- Someone must physically unlock it (or remotely via screen sharing if network comes up before FileVault blocks it — this is unreliable)

**Options:**
1. **Disable FileVault** — acceptable on a physically secured machine on a private network
2. **Use an encrypted external volume** for sensitive data, leave the boot volume unencrypted
3. **Accept the manual intervention** on reboot — the machine runs unattended day-to-day, but reboots require physical presence

For most private-network CI machines in a home lab or office, disabling FileVault is the pragmatic choice.

---

## Distribution model

This is **not an App Store application**. Direct distribution (notarized `.pkg` installer or simple binary) is the intended approach.

This means:
- No sandbox restrictions
- LaunchDaemon and LaunchAgent installation works normally
- Virtualization.framework entitlement (`com.apple.security.virtualization`) can be requested without App Store review
- App Groups and XPC services can be used freely

The binary must be **notarized** with Apple for Gatekeeper to allow execution on target machines. This requires:
- An Apple Developer account
- Code signing certificate (Developer ID Application)
- `codesign` + `notarytool` in the build/release pipeline

---

## Required entitlements

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <!-- Required for Virtualization.framework -->
    <key>com.apple.security.virtualization</key>
    <true/>

    <!-- Required for network access (GitHub API polling) -->
    <key>com.apple.security.network.client</key>
    <true/>

    <!-- Required for reading/writing base images and clones -->
    <key>com.apple.security.files.user-selected.read-write</key>
    <true/>

    <!-- Required for Apple Containerization framework -->
    <key>com.apple.security.virtualization</key>
    <true/>
</dict>
</plist>
```
