# Architecture
## Human-Readable Design Document

---

## The big picture

The orchestrator is a single long-running Swift executable. It has no UI, no HTTP server, no user-facing interface. Think of it like a well-behaved Unix service: it starts on boot, watches for work, does the work, logs what happened, and shuts down cleanly when asked.

The entire system is built on **Swift Structured Concurrency** — async/await, actors, task groups. No Grand Central Dispatch, no manual threads, no callbacks.

---

## Components and responsibilities

### JobScheduler (actor)

The central brain. Everything flows through it.

- Owns the in-memory job queue
- Routes jobs to the right manager (VM or container) based on `runs-on` labels
- Tracks the state of every active job
- Enforces the concurrency limit (how many jobs run simultaneously)
- Handles timeouts and error recovery
- Calls into `GitHubClient` for registration tokens
- Receives completion signals and triggers teardown

The `JobScheduler` is intentionally ignorant of VM internals and container internals. It knows only job states and delegates everything else.

### GitHubClient (actor)

All GitHub API communication. Owns the token lifecycle.

- Generates GitHub App JWTs (RS256, signed with the private key)
- Exchanges JWTs for installation access tokens (60-minute lifetime, auto-refreshed)
- Polls for queued workflow jobs
- Fetches runner registration tokens (one per job, ephemeral)
- Reports nothing back to GitHub directly — `actions/runner` inside the VM handles that

### VMManager (actor)

Everything related to macOS VMs.

- Holds a reference to the base disk image path
- Creates APFS copy-on-write clones via `clonefile()` system call
- Configures and boots `VZVirtualMachine` with the right CPU/memory/disk/network
- Passes the runner registration token into the VM at boot (via a shared directory or virtio socket)
- Monitors the VM process for exit
- Destroys the cloned disk image on teardown

### ContainerManager (actor)

Everything related to Linux containers.

- Pulls or verifies OCI-compatible container images (ubuntu, debian, etc.)
- Creates ephemeral containers via Apple's Containerization framework
- Passes runner token in, monitors exit, destroys container on completion

### Logger

Not an actor — a shared `swift-log` instance with a file backend. Every component writes to it. Rotating log file on disk. See `LOGGING.md` for format spec.

---

## Job state machine

Every job moves through these states exactly once (except on retry):

```
.queued
   │
   ▼
.provisioning    ← clone VM disk or create container
   │
   ▼
.booting         ← VZVirtualMachine.start() or container.start()
   │
   ▼
.running         ← actions/runner has picked up the job
   │
   ▼
.teardown        ← destroy clone, reclaim disk
   │
   ▼
.complete
```

Error states branch off at any stage:

```
.provisioning → .failed(reason: .diskCloneFailed)
.booting      → .failed(reason: .vmBootTimeout)
.running      → .failed(reason: .runnerCrashed)
.teardown     → .failed(reason: .cleanupFailed)  ← non-fatal, job still "done"
```

A `.failed` job logs the failure and the slot is freed. No automatic retry in MVP (jobs can be re-queued from GitHub's side).

---

## Data flow — macOS job (happy path)

```
GitHubClient
  │  polls GitHub, finds queued job with [self-hosted, macos]
  │
  ▼
JobScheduler
  │  accepts job, state → .provisioning
  │  calls GitHubClient.registrationToken(for: job)
  │  calls VMManager.provision(job: job, token: token)
  │
  ▼
VMManager
  │  clonefile() → new disk image at /tmp/cirunner/jobs/{jobID}/disk.img
  │  configure VZVirtualMachineConfiguration
  │  state → .booting
  │  VZVirtualMachine.start()
  │
  ▼
[inside VM]
  │  actions/runner starts on boot (LaunchDaemon inside guest)
  │  config.sh --url {repo} --token {token} --ephemeral
  │  runner picks up the queued job
  │  job executes
  │  runner exits
  │  VM shuts down
  │
  ▼
VMManager
  │  detects VM exit
  │  notifies JobScheduler via continuation/callback
  │
  ▼
JobScheduler
  │  state → .teardown
  │  calls VMManager.destroy(jobID: jobID)
  │
  ▼
VMManager
  │  deletes /tmp/cirunner/jobs/{jobID}/disk.img
  │  state → .complete
  │
  ▼
Logger
     writes completion record with duration, exit code, disk delta
```

---

## Concurrency design

Each job runs in its own Swift `Task`, managed as a child of a `TaskGroup` inside `JobScheduler`. Cancellation propagates naturally. The concurrency limit is enforced at the `JobScheduler` level before provisioning starts.

```swift
// Conceptual sketch — not final implementation
actor JobScheduler {
    let maxConcurrent: Int
    var activeJobs: [JobID: JobState] = [:]

    func run() async {
        await withTaskGroup(of: Void.self) { group in
            for await job in gitHubClient.jobStream() {
                guard activeJobs.count < maxConcurrent else {
                    // park job in pending queue
                    continue
                }
                group.addTask {
                    await self.handle(job: job)
                }
            }
        }
    }
}
```

---

## Communication between orchestrator and VM

The hardest open question in the design. The orchestrator needs to pass the runner registration token into the VM, and needs to know when the runner exits.

**Recommended approach: shared directory via VirtioFS**

Virtualization.framework supports `VZVirtioFileSystemDeviceConfiguration` — a shared directory between host and guest. The orchestrator writes a small JSON file to the shared directory before booting, the guest reads it on startup.

```
Host writes: /tmp/cirunner/jobs/{jobID}/runner-config.json
Guest reads: /mnt/cirunner/runner-config.json (via VirtioFS mount)
```

The guest startup script (`/etc/cirunner/boot.sh`, installed in the base image) reads this file and invokes `actions/runner`'s `config.sh` with the token.

**VM exit detection:** the `VZVirtualMachine` delegate method `virtualMachineDidStop(_:)` fires when the VM halts. This is the signal that the job is done.

---

## What the orchestrator does NOT do

- Does not serve HTTP
- Does not have a web UI or dashboard
- Does not manage multiple Xcode versions
- Does not distribute base images (you build your own from IPSW)
- Does not run `actions/runner` on the host — only inside VMs/containers
- Does not retry failed jobs automatically (GitHub handles re-queuing)
