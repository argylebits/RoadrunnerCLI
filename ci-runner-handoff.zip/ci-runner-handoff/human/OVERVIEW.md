# Swift CI Runner Orchestrator
## Human-Readable Project Overview

---

## What problem does this solve?

Self-hosted GitHub Actions runners on macOS need clean environments per job. The dominant solution (Cilicon/Tart) solves this by pulling pre-built OCI images from a registry — images that are 50–100 GB each. On a machine with multiple Xcode versions, you're looking at hundreds of GB of disk usage just for CI images.

This project takes a different approach: one lean base image built from Apple's own IPSW restore format (~55 GB total with full Xcode), cloned per job using APFS copy-on-write (near-zero additional disk per job), destroyed after the job completes. The result is true clean-state CI at a fraction of the cost.

---

## How does it work?

```
┌──────────────────────────────────────────────────────────┐
│                    macOS Host Machine                     │
│                                                           │
│  Orchestrator daemon (always running)                     │
│  ├── Polls GitHub for queued CI jobs                      │
│  ├── When job arrives:                                    │
│  │   ├── macOS job → APFS clone base VM → boot → run     │
│  │   └── Linux job → spin up container → run             │
│  └── When job completes → destroy clone/container        │
│                                                           │
│  Base macOS image (55 GB, lives on disk permanently)      │
│  └── APFS clones per job (only changed bytes charged)     │
└──────────────────────────────────────────────────────────┘
         ↕ GitHub API (outbound polling only)
   GitHub Actions
```

The key insight is **APFS copy-on-write cloning**. When you clone a file with APFS, you don't copy the data — you just create a new reference to the same blocks. As the job writes to the clone, only the changed blocks are allocated. A typical CI job might write 2–3 GB of build artifacts, so each clone costs 2–3 GB, not 55 GB. When the job finishes, you delete the clone and reclaim everything.

---

## Technology choices

| Concern | Choice | Why |
|---|---|---|
| Language | Swift | Native Apple frameworks, familiar stack |
| macOS VMs | Virtualization.framework (direct) | No Tart/Cilicon wrapper needed |
| Linux containers | Apple Containerization framework | Native Swift API, per-container VM isolation |
| GitHub auth | GitHub App (private key) | Already provisioned, better than PAT |
| Process management | launchd (LaunchAgent) | Standard macOS daemon pattern |
| Logging | swift-log + file backend | Simple, inspectable, `tail -f` friendly |
| Config | YAML | Human-readable, easy to edit |
| Database | GRDB (raw SQL) | Job history, audit log — if needed |

---

## Deployment model

The orchestrator runs as a **LaunchAgent** under a dedicated `ci` user with auto-login enabled. This is required because `Virtualization.framework` needs an active WindowServer session — it cannot run from a root-level LaunchDaemon.

The machine boots → auto-logs in as `ci` → LaunchAgent starts → orchestrator is ready. Nobody needs to be at the keyboard. This is the same pattern used by Cilicon, Tart-based setups, and most Mac CI providers.

See `DEPLOYMENT.md` for a full analysis of LaunchDaemon vs LaunchAgent trade-offs.

---

## Job lifecycle (step by step)

1. Orchestrator polls GitHub API, finds a queued workflow job
2. Checks the `runs-on` label to route: `[self-hosted, macos]` or `[self-hosted, linux]`
3. Fetches a runner registration token from GitHub API
4. **macOS path:** APFS-clones the base disk image, boots a `VZVirtualMachine`
5. **Linux path:** Creates an ephemeral container via Containerization framework
6. Injects the registration token into the environment at boot
7. Inside the VM/container: `actions/runner` runs `config.sh`, registers as an ephemeral runner, picks up the queued job
8. Job executes, `actions/runner` exits (ephemeral mode — one job then done)
9. VM shuts down / container stops
10. Orchestrator detects exit, destroys the clone
11. Loop

---

## What this is NOT

- Not a web app or API server
- Not a dashboard or UI
- Not a multi-tenant SaaS product
- Not a replacement for GitHub-hosted runners (it's a self-hosted alternative)
- Not tied to OCI image registries
- Not Tart, not Cilicon, not a wrapper around anything

---

## Project status

Design complete. Implementation not started. This document package is the handoff from design to implementation.

---

## Key files to read next

- `ARCHITECTURE.md` — component design, actor model, data flow
- `DEPLOYMENT.md` — LaunchAgent vs LaunchDaemon, installation
- `VM_LIFECYCLE.md` — Virtualization.framework, APFS cloning, base image
- `CONTAINER_LIFECYCLE.md` — Apple Containerization framework
- `GITHUB_API.md` — GitHub App auth, polling, runner registration
