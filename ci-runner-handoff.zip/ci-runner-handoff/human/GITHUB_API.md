# GitHub API Integration
## Human-Readable Guide

---

## Authentication: GitHub App

The orchestrator authenticates as a **GitHub App**, not as a user. This is the correct approach for machine-to-machine automation — it gives scoped permissions, better rate limits, and doesn't tie access to a personal account.

A GitHub App private key already exists in the project (`ciliconrunner.2026-03-12.private-key.pem`). The App is already installed on the target organization/repository.

### Token lifecycle

GitHub App auth works in two steps:

```
Step 1: Generate a JWT (JSON Web Token)
  - Signed with the App's private key (RS256)
  - Claims: iss (app ID), iat (now), exp (now + 10 minutes)
  - This JWT proves you are the GitHub App

Step 2: Exchange JWT for an Installation Access Token
  - POST /app/installations/{installation_id}/access_tokens
  - Authorization: Bearer {JWT}
  - Returns: { "token": "ghs_...", "expires_at": "..." }
  - Installation Access Token lasts 60 minutes
  - Use this token for all subsequent API calls
```

The `GitHubClient` actor manages this automatically — it refreshes the Installation Access Token before it expires.

### JWT generation (Swift)

```swift
// Requires a JWT library or manual implementation
// The JWT payload for GitHub App auth:
let payload = [
    "iss": appID,        // GitHub App ID (numeric string)
    "iat": nowTimestamp, // issued at
    "exp": nowTimestamp + 540  // expires in 9 minutes (give 1 min buffer)
]
// Sign with RS256 using the private key PEM file
```

Note: Swift does not have a built-in JWT library. Options:
- `swift-jwt` (IBM, Apache 2.0)
- Manual implementation using `CryptoKit` (RS256 via `_CryptoExtras` or `SwiftCrypto`)
- `JWTKit` (Vapor project, well-maintained)

**Recommended:** `JWTKit` — it's the most maintained Swift JWT library and handles RS256 cleanly.

---

## Job discovery: polling

The MVP uses polling. Webhooks are a future enhancement.

### Polling endpoint

For repository-level runners:
```
GET /repos/{owner}/{repo}/actions/runs?status=queued
```

For organization-level runners:
```
GET /orgs/{org}/actions/runs?status=queued
```

**Poll interval:** Configurable, default 15 seconds. Respect GitHub's rate limits — the Installation Access Token gets 5,000 requests/hour, polling at 15s uses ~240 requests/hour, well within budget.

### Identifying jobs for this runner

The API returns workflow runs, not individual jobs. To find the specific jobs:

```
GET /repos/{owner}/{repo}/actions/runs/{run_id}/jobs?filter=queued
```

Check the `labels` array on each job:
```json
{
  "id": 123456,
  "name": "build",
  "status": "queued",
  "labels": ["self-hosted", "macos"]
}
```

Route based on labels:
- Contains `macos` → `VMManager`
- Contains `linux` → `ContainerManager`

### Handling duplicates

The orchestrator must track which job IDs it has already claimed to avoid double-processing. Keep an in-memory set of active job IDs. On each poll, skip any job ID already in the active set.

---

## Runner registration

Each job needs its own ephemeral runner registration. This is a two-step process.

### Step 1: Get a registration token

```
POST /repos/{owner}/{repo}/actions/runners/registration-token
Authorization: Bearer {installation_access_token}
```

Response:
```json
{
  "token": "AABBCC...",
  "expires_at": "2026-03-12T15:00:00Z"
}
```

This token is single-use and expires in 1 hour. Fetch it just before booting the VM.

### Step 2: Pass the token into the VM/container

The token gets passed to `actions/runner`'s configuration script inside the VM:

```bash
# Inside the VM (run by the startup script)
./config.sh \
  --url https://github.com/{owner}/{repo} \
  --token {registration_token} \
  --name cirunner-{jobID} \
  --labels self-hosted,macos \
  --ephemeral \
  --unattended

# Then start the runner
./run.sh
```

The `--ephemeral` flag is critical — it means the runner de-registers itself after completing one job. You never need to manually de-register runners.

### Passing the token securely

The token must get from the orchestrator (on the host) into the VM. The recommended approach is a **VirtioFS shared directory**:

1. Orchestrator writes `/tmp/cirunner/jobs/{jobID}/runner-env.json` on the host
2. VirtioFS maps this into the guest at `/cirunner/runner-env.json`
3. The guest startup script reads the file and runs `config.sh`
4. After `config.sh` runs, the script deletes the file (token consumed)

```json
// runner-env.json
{
  "registration_token": "AABBCC...",
  "repo_url": "https://github.com/owner/repo",
  "runner_name": "cirunner-{jobID}",
  "labels": ["self-hosted", "macos"]
}
```

---

## API rate limits

| Token type | Rate limit |
|---|---|
| GitHub App Installation Access Token | 5,000 requests/hour |
| Unauthenticated | 60 requests/hour |
| GitHub Actions API (runner registration) | Generous, not typically a concern |

At 15-second polling intervals, you use approximately 240 requests/hour for job discovery, leaving ample budget for runner registration tokens and other calls.

---

## Webhook option (future)

Instead of polling, GitHub can push `workflow_job` events to a webhook endpoint. This gives instant job notification instead of up to 15-second delay.

**Requires:**
- An HTTP server listening on a public port
- A Cloudflare Tunnel, ngrok, or similar if the machine is behind NAT
- Webhook secret validation (HMAC-SHA256)

**Event payload:**
```json
{
  "action": "queued",
  "workflow_job": {
    "id": 123456,
    "labels": ["self-hosted", "macos"],
    "run_id": 789,
    "head_sha": "abc123"
  },
  "repository": {
    "full_name": "owner/repo"
  }
}
```

Implementing this requires adding a minimal HTTP listener (Hummingbird or bare Network.framework). This is deferred to post-MVP.

---

## Error handling

| Scenario | Behavior |
|---|---|
| Poll returns no queued jobs | Normal — sleep interval, poll again |
| API returns 401 | Refresh Installation Access Token, retry once |
| API returns 403 | Log error, alert operator, back off |
| API returns 429 (rate limited) | Respect `Retry-After` header, back off |
| Network unreachable | Log warning, retry with exponential backoff |
| Registration token expired before use | Fetch a new one |
