# VM Lifecycle
## Human-Readable Guide

---

## Overview

Every macOS CI job gets its own ephemeral VM. The VM is created by APFS-cloning a permanent base image, booted for the duration of the job, then destroyed. The base image is never modified.

```
Base image (permanent, ~55 GB)
   │
   ├── clonefile() → job-abc123.img (ephemeral, ~2-3 GB delta)
   │                      │
   │                      ├── Boot VZVirtualMachine
   │                      ├── Run CI job
   │                      ├── VM shuts down
   │                      └── Delete job-abc123.img ✓
   │
   └── Next job...
```

---

## Base image creation

The base image is created once manually and stored on the host. It is never pulled from a registry.

### What the base image contains

- macOS (installed from IPSW via `VZMacOSInstaller`)
- Full Xcode (one version — see sizing below)
- `actions/runner` pre-installed at `/opt/runner/`
- A startup script at `/etc/cirunner/boot.sh` that reads the runner config and starts the runner
- A LaunchDaemon inside the guest that runs `boot.sh` on startup

### Size breakdown

| Component | Size |
|---|---|
| Bare macOS | ~15–20 GB |
| Xcode (full, one version) | ~30–35 GB |
| actions/runner | ~500 MB |
| **Total** | **~50–55 GB** |

### IPSW source

Apple publishes IPSW restore images at `updates.cdn-apple.com`. The `VZMacOSRestoreImage.latestSupported` API can find and download the appropriate image for the host hardware.

```swift
// Fetch the latest supported restore image for this Mac
let restoreImage = try await VZMacOSRestoreImage.latestSupported
let downloadURL = restoreImage.url
```

### Installation process (one-time setup)

This is a CLI command, not part of the daemon:

```bash
cirunner setup-base-image \
  --output ~/.cirunner/base-images/macos-xcode.img \
  --xcode-path /Applications/Xcode.app
```

The `setup-base-image` subcommand:
1. Downloads latest supported macOS IPSW
2. Creates a new VM disk image
3. Boots a VM and runs `VZMacOSInstaller`
4. Mounts the disk, installs Xcode (or copies pre-downloaded Xcode.app)
5. Installs `actions/runner`
6. Installs the boot script and guest LaunchDaemon
7. Shuts down and seals the image

This takes 30–60 minutes and is done once (or when you update Xcode).

---

## APFS cloning

APFS copy-on-write cloning is the core disk efficiency mechanism.

### How it works

`clonefile()` is a system call that creates a new directory entry pointing to the same APFS extents (data blocks) as the original file. No data is copied. The clone is instant regardless of file size.

As the clone is written to during the CI job, only the changed blocks are allocated. Read operations on unchanged blocks still read from the original extents.

```swift
// Clone the base image for a new job
let basePath = config.vm.baseImagePath
let clonePath = jobDirectory.appendingPathComponent("disk.img")

let result = clonefile(basePath.path, clonePath.path, 0)
guard result == 0 else {
    throw VMError.cloneFailed(errno: errno)
}
```

### Disk usage reality

- Base image: 55 GB (permanent, shared across all jobs)
- Per running job: typically 1–4 GB (only bytes written during the job)
- Deleted after job: 0 GB (clone deleted, base image untouched)

Running 4 concurrent jobs uses ~55 GB + (4 × ~3 GB) = ~67 GB. Compare to Cilicon/Tart pulling a separate full image per Xcode version.

---

## Virtualization.framework integration

### VM configuration

```swift
func makeVMConfiguration(
    diskImagePath: URL,
    cpuCount: Int,
    memoryGB: Int,
    sharedDirectory: URL
) throws -> VZVirtualMachineConfiguration {
    let config = VZVirtualMachineConfiguration()

    // CPU
    config.cpuCount = cpuCount

    // Memory
    config.memorySize = UInt64(memoryGB) * 1024 * 1024 * 1024

    // Boot loader
    let bootLoader = VZMacOSBootLoader()
    config.bootLoader = bootLoader

    // Disk
    let diskAttachment = try VZDiskImageStorageDeviceAttachment(
        url: diskImagePath,
        readOnly: false
    )
    let storageDevice = VZVirtioBlockDeviceConfiguration(attachment: diskAttachment)
    config.storageDevices = [storageDevice]

    // Network (NAT — simplest, no bridging needed)
    let networkDevice = VZVirtioNetworkDeviceConfiguration()
    networkDevice.attachment = VZNATNetworkDeviceAttachment()
    config.networkDevices = [networkDevice]

    // Shared directory (VirtioFS — for passing runner token)
    let sharedDir = VZSharedDirectory(url: sharedDirectory, readOnly: false)
    let sharing = VZVirtioFileSystemDeviceConfiguration(tag: "cirunner")
    sharing.share = VZSingleDirectoryShare(directory: sharedDir)
    config.directorySharingDevices = [sharing]

    // Graphics (required for user session — headless display)
    let graphicsConfig = VZMacGraphicsDeviceConfiguration()
    graphicsConfig.displays = [
        VZMacGraphicsDisplayConfiguration(widthInPixels: 1280, heightInPixels: 800, pixelsPerInch: 72)
    ]
    config.graphicsDevices = [graphicsConfig]

    try config.validate()
    return config
}
```

### Booting and monitoring

```swift
// Conceptual — VMManager actor method
func bootVM(config: VZVirtualMachineConfiguration, jobID: JobID) async throws {
    let vm = VZVirtualMachine(configuration: config)
    vm.delegate = self  // VMManager conforms to VZVirtualMachineDelegate

    activeVMs[jobID] = vm

    try await vm.start()
    // VM is now booting — delegate will fire on stop
}

// VZVirtualMachineDelegate
func virtualMachineDidStop(_ virtualMachine: VZVirtualMachine) {
    // Find the jobID for this VM
    // Notify JobScheduler that the job is complete
}

func virtualMachine(_ virtualMachine: VZVirtualMachine, didStopWithError error: Error) {
    // VM crashed — notify JobScheduler of failure
}
```

### Guest startup script (installed in base image)

The base image contains `/etc/cirunner/boot.sh`:

```bash
#!/bin/bash
set -e

# Mount the VirtioFS share (tag matches host config)
mkdir -p /cirunner
mount -t virtiofs cirunner /cirunner

# Read runner configuration
CONFIG_FILE="/cirunner/runner-env.json"
if [ ! -f "$CONFIG_FILE" ]; then
    echo "ERROR: No runner config found at $CONFIG_FILE" >&2
    exit 1
fi

REPO_URL=$(jq -r '.repo_url' "$CONFIG_FILE")
TOKEN=$(jq -r '.registration_token' "$CONFIG_FILE")
RUNNER_NAME=$(jq -r '.runner_name' "$CONFIG_FILE")
LABELS=$(jq -r '.labels | join(",")' "$CONFIG_FILE")

# Delete the config file (token consumed)
rm -f "$CONFIG_FILE"

# Configure and start actions/runner
cd /opt/runner
./config.sh \
    --url "$REPO_URL" \
    --token "$TOKEN" \
    --name "$RUNNER_NAME" \
    --labels "$LABELS" \
    --ephemeral \
    --unattended

./run.sh

# Runner exits after one job (ephemeral mode)
# Shut down the VM
shutdown -h now
```

A `LaunchDaemon` inside the guest (installed in the base image) runs this script at boot as root.

---

## Teardown

After the VM shuts down (detected via `VZVirtualMachineDelegate`):

1. Remove the cloned disk image: `FileManager.default.removeItem(at: clonePath)`
2. Remove the shared directory: `FileManager.default.removeItem(at: sharedDirPath)`
3. Free the `VMManager` slot for the next job
4. Notify `JobScheduler` of completion

Teardown is fast — deleting an APFS file is near-instant regardless of the file's apparent size.

---

## Networking

The VM uses NAT networking (`VZNATNetworkDeviceAttachment`). This gives the VM:
- Outbound internet access (for GitHub API calls from inside the runner, package downloads, etc.)
- No inbound access from outside (the VM is not directly reachable from the network)

NAT is sufficient for CI workloads. Bridged networking is not needed unless a job requires a specific local IP or network service discovery — not a concern for standard CI.

The VM gets an IP in the `192.168.64.x` range assigned by the macOS NAT layer. The orchestrator does not need to know the VM's IP.
