# Open Questions
## Decisions Required Before or During Implementation

---

These are the unresolved design questions as of the handoff. Some must be answered before implementation starts. Others can be deferred to when the relevant component is being built.

---

## Must resolve before starting

### 1. Project name

The working name is "cirunner" / "CIRunner". The original design doc used "CiliconRunner" which is confusing given that one of the design goals is explicitly *not being Cilicon*.

**Decision needed:** What is the final project name? This affects:
- Swift package name
- Binary name (`cirunner` vs something else)
- LaunchAgent label (`com.cirunner.orchestrator` vs `com.{name}.orchestrator`)
- GitHub repository name

**Suggestion:** Something that conveys "ephemeral macOS CI" without referencing Cilicon. Consider: `vela`, `ephemeron`, `clonerunner`, `apfsrunner`, or simply `swift-ci-runner`.

### 2. Repo vs org level

The GitHub API integration can target a single repository or an entire GitHub organization. These use different API endpoints and have different token scope requirements.

**Decision needed:** Does this tool serve a single repo or an org?

- **Single repo:** Simpler auth, easier to reason about, sufficient for personal use
- **Org level:** More useful if you have many repos, but more complex routing and token scoping

**Recommendation:** Config-driven — support both, with the user specifying either `owner/repo` or `org` in `config.yaml`.

---

## Resolve when building the relevant component

### 3. Runner token injection method (VM → host communication)

The design recommends VirtioFS shared directory. Confirm this works reliably for the macOS version in use and that the guest can mount the VirtioFS share before `actions/runner` needs to run.

**Alternative:** Write a small plist/JSON to a location the VM startup script can access via a different mechanism (network share, virtio serial console, etc.)

### 4. Runner auto-start inside the VM guest

The boot script approach is documented. The question is how the guest LaunchDaemon is structured and whether there are timing issues (e.g., VirtioFS mount not ready when the LaunchDaemon fires).

**Consideration:** Use `WaitForDependency` in the guest LaunchDaemon plist to wait for the VirtioFS mount before running the boot script.

### 5. Concurrency limit

What is the default max concurrent jobs? The right answer depends on host machine specs.

**Recommendation:** Default to 2, make it configurable. Document that 4 vCPUs and 8 GB RAM per VM is the minimum — so a Mac Studio with 24 cores and 64 GB RAM can safely run ~6–8 concurrent jobs.

### 6. Base image update workflow

When a new Xcode version drops, the base image needs to be rebuilt. The `setup-base-image` command handles this, but questions remain:

- Is the old base image automatically replaced or versioned?
- What happens to jobs running against the old image while the new one is being built?
- Should there be a `--keep-old` flag?

### 7. Error handling: what happens when disk runs out?

If the host runs out of disk space mid-clone, `clonefile()` will fail. The orchestrator needs to:
- Detect the failure
- Report it clearly (not just a cryptic errno)
- Potentially stop accepting new jobs until space is recovered

**Decision:** Should the orchestrator proactively check available disk before cloning? How much headroom should it require?

### 8. Logging verbosity levels

The logging spec defines DEBUG, INFO, WARNING, ERROR. What should be logged at each level?

**Suggested defaults:**
- **DEBUG:** Every API call, every state transition, VM boot events
- **INFO:** Job start, job complete, registration token acquired
- **WARNING:** API retry, slow boot, disk usage above threshold
- **ERROR:** Clone failed, VM boot timeout, GitHub auth failure

### 9. macOS version in the guest

The base image can run any macOS version the host supports. Should the tool default to "same as host" or should this be configurable?

**Consideration:** If the tool is used to test macOS app compatibility, the ability to run a different guest macOS version than the host is valuable. But it adds base image management complexity.

### 10. Handling stale runner registrations

If the orchestrator crashes mid-job, the ephemeral runner may be left registered but idle in GitHub. GitHub will eventually clean these up, but the timeout is configurable. Should the orchestrator query for and clean up stale registrations at startup?

---

## Nice-to-have (post-MVP)

- Webhook support instead of polling
- Multi-Xcode-version base images
- Linux container support (ContainerManager — requires macOS 26)
- `cirunner status` CLI command to show active jobs
- Prometheus metrics endpoint
- Slack/webhook notifications on job failure
