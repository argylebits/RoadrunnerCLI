#!/bin/bash
# /etc/cirunner/boot.sh
#
# This script is installed in the base macOS VM image.
# It runs at VM boot via a LaunchDaemon (see com.cirunner.runner.plist).
# It reads the runner configuration from the VirtioFS shared directory,
# registers actions/runner with GitHub, runs the job, then shuts down.
#
# This script runs INSIDE the guest VM — not on the host.

set -euo pipefail

CIRUNNER_MOUNT="/cirunner"
CONFIG_FILE="$CIRUNNER_MOUNT/runner-env.json"
RUNNER_DIR="/opt/runner"
LOG_FILE="/var/log/cirunner-boot.log"

log() {
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $1" | tee -a "$LOG_FILE"
}

log "CIRunner boot script starting"

# Mount the VirtioFS share from the host
# The mount tag 'cirunner' matches VZVirtioFileSystemDeviceConfiguration(tag: "cirunner")
log "Mounting VirtioFS share..."
mkdir -p "$CIRUNNER_MOUNT"
mount -t virtiofs cirunner "$CIRUNNER_MOUNT"

# Wait for the config file (host writes it before booting the VM,
# but add a brief wait just in case of timing)
RETRIES=10
while [ ! -f "$CONFIG_FILE" ] && [ $RETRIES -gt 0 ]; do
    log "Waiting for runner config... ($RETRIES retries left)"
    sleep 1
    RETRIES=$((RETRIES - 1))
done

if [ ! -f "$CONFIG_FILE" ]; then
    log "ERROR: runner-env.json not found after waiting. Shutting down."
    shutdown -h now
    exit 1
fi

# Parse the config (requires jq installed in base image)
REPO_URL=$(jq -r '.repoURL' "$CONFIG_FILE")
TOKEN=$(jq -r '.registrationToken' "$CONFIG_FILE")
RUNNER_NAME=$(jq -r '.runnerName' "$CONFIG_FILE")
LABELS=$(jq -r '.labels | join(",")' "$CONFIG_FILE")

log "Runner config loaded: name=$RUNNER_NAME repo=$REPO_URL labels=$LABELS"

# Delete the config file — token is consumed, don't leave it on disk
rm -f "$CONFIG_FILE"
log "Runner config deleted (token consumed)"

# Unmount the share — no longer needed
umount "$CIRUNNER_MOUNT"

# Configure actions/runner
log "Configuring actions/runner..."
cd "$RUNNER_DIR"

./config.sh \
    --url "$REPO_URL" \
    --token "$TOKEN" \
    --name "$RUNNER_NAME" \
    --labels "$LABELS" \
    --ephemeral \
    --unattended

log "Runner configured. Starting..."

# Run the job (--ephemeral means this exits after one job)
./run.sh
EXIT_CODE=$?

log "Runner exited with code $EXIT_CODE. Shutting down VM."

# Shut down the VM — the host detects this via VZVirtualMachineDelegate
shutdown -h now
