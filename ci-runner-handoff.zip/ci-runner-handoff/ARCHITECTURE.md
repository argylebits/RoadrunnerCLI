# Architecture

## System overview

The orchestrator is a long-running Swift executable managed by launchd. It has no UI, no HTTP server, and no user-facing interface. It is a daemon with a single responsibility: watch GitHub for queued CI jobs, provision clean ephemeral environments, run the jobs, and destroy the environments.

```
┌─────────────────────────────────────────────────────────────────┐
│                        macOS Host                                │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │               Swift Orchestrator (daemon)                 │   │
│  │                                                           │   │
│  │   ┌─────────────┐    ┌──────────────┐   ┌─────────────┐  │   │
│  │   │JobScheduler │    │  VMManager   │   │ Container   │  │   │
│  │   │   (actor)   │───▶│   (actor)    │   │  Manager    │  │   │
│  │   │             │    │              │   │  (actor)    │  │   │
│  │   │             │───▶└──────────────┘   └─────────────┘  │   │
│  │   └──────┬──────┘           │                  │          │   │
│  │          │                  ▼                  ▼          │   │
│  │   ┌──────▼──────┐    ┌──────────────┐   ┌─────────────┐  │   │
│  │   │GitHub Client│    │  macOS VM    │   │   Linux     │  │   │
│  │   │  (actor)    │    │  (ephemeral) │   │  Container  │  │   │
│  │   └─────────────┘    └──────────────┘   └─────────────┘  │   │
│  │                                                           │   │
│  │   ┌──────────────────────────────────────────────────┐   │   │
│  │   │              swift-log (file backend)             │   │   │
│  │   └──────────────────────────────────────────────────┘   │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
         │
         ▼
   GitHub Actions API
   (outbound only, polling)
```

## Actor model

All major subsystems are Swift actors. This provides data race safety and clear ownership boundaries without manual locking.

### `JobScheduler` actor

The central coordinator. Owns the in-memory job queue. Dispatches work to `VMManager` or `ContainerManager` based on job routing. Receives completion/failure callbacks and handles teardown.

**Responsibilities:**
- Maintain queue of pending jobs
- Route jobs by `runs-on` label
- Enforce concurrency limits (configurable max concurrent jobs)
- Track active job states
- Handle timeout logic
- Coordinate teardown after completion or failure

**Does NOT:**
- Talk to GitHub directly (delegates to `GitHubClient`)
- Know about VM internals (delegates to `VMManager`)
- Know about container internals (delegates to `ContainerManager`)

### `GitHubClient` actor

All GitHub API communication lives here. Owns the GitHub App auth token lifecycle (JWT generation, installation access token refresh). Polls for queued jobs. Fetches runner registration tokens.

**Responsibilities:**
- GitHub App JWT generation (RS256, from private key)
- Installation access token acquisition and refresh
- Polling `GET /repos/{owner}/{repo}/actions/runs` or org-level equivalent
- Generating runner registration tokens via `POST .../registration-token`
- Reporting runner status

**Does NOT:**
- Make decisions about job routing
- Know about VMs or containers

### `VMManager` actor

Owns the macOS VM lifecycle. Wraps Virtualization.framework. Manages the base image and produces ephemeral clones on demand.

**Responsibilities:**
- Load and validate base VM disk image
- Create APFS copy-on-write clone via `clonefile()`
- Configure and boot `VZVirtualMachine` with appropriate resources
- Pass runner registration token into VM at boot
- Monitor VM process, detect exit
- Destroy clone on teardown (delete cloned disk image)

**Does NOT:**
- Know about GitHub
- Know about job routing

### `ContainerManager` actor

Owns the Linux container lifecycle. Wraps Apple's Containerization framework.

**Responsibilities:**
- Pull or verify OCI-compatible Linux images
- Create ephemeral container with `actions/runner` pre-installed
- Start container, pass runner token
- Monitor container exit
- Remove container on teardown

**Does NOT:**
- Know about GitHub
- Know about job routing

## Data flow

### Happy path — macOS job

```
1. GitHubClient polls GitHub, finds queued job with label [self-hosted, macos]
2. GitHubClient notifies JobScheduler with JobDescriptor
3. JobScheduler checks concurrency limits, accepts job
4. JobScheduler transitions job state: .queued → .provisioning
5. JobScheduler calls VMManager.provisionVM(for: job)
6. VMManager clones base disk image via clonefile()
7. VMManager configures VZVirtualMachine (CPU, memory, disk, network)
8. JobScheduler fetches runner registration token from GitHubClient
9. JobScheduler transitions job state: .provisioning → .booting
10. VMManager boots VM, injects registration token
11. Inside VM: actions/runner runs config.sh with token, registers as ephemeral runner
12. Inside VM: actions/runner picks up the queued job, executes it
13. JobScheduler transitions job state: .booting → .running
14. actions/runner exits after job completes (ephemeral mode — one job, then exit)
15. VM shuts down
16. VMManager detects VM exit, notifies JobScheduler
17. JobScheduler transitions job state: .running → .teardown
18. VMManager deletes cloned disk image
19. JobScheduler transitions job state: .teardown → .complete
20. Logger writes completion record
21. JobScheduler polls for next job
```

### Happy path — Linux job

Same flow, replacing steps 5-15 with ContainerManager equivalents. Container startup is sub-second vs VM boot time of several seconds.

### Error paths

See `JOB_SCHEDULER.md` for full error state machine and retry/recovery logic.

## Concurrency model

The orchestrator is built on Swift Structured Concurrency (async/await, actors, task groups). No Grand Central Dispatch, no manual threads, no DispatchQueue.

Key patterns:
- Each job runs in its own `Task`, child of a `TaskGroup` owned by `JobScheduler`
- Cancellation propagates cleanly through the task tree
- `AsyncStream` used for job event notifications between actors
- `AsyncStream` used to receive GitHub polling results

## Process management approach

The orchestrator spawns `actions/runner` processes inside VMs/containers — not on the host. The host process never directly forks `actions/runner`. All runner execution is isolated inside the ephemeral environment.

The orchestrator detects job completion by:
1. (Primary) Monitoring the VM/container exit status
2. (Secondary) GitHub API confirmation of job completion

## Virtualization.framework constraint

Virtualization.framework requires a WindowServer session — it cannot run from a root LaunchDaemon with no logged-in user. See `DEPLOYMENT.md` for the full analysis of deployment options and the recommended approach.
