# Swift CI Runner Orchestrator — Agent Handoff Package

## What this is

A handoff package for a Claude Code agent to implement a Swift-native CI runner orchestrator for GitHub Actions. This document is your entry point. Read every file in this package before writing a single line of code.

## Package contents

| File | Purpose |
|------|---------|
| `README.md` | This file — start here |
| `ARCHITECTURE.md` | Full system architecture, component design, actor model |
| `DEPLOYMENT.md` | LaunchDaemon vs LaunchAgent analysis, deployment models, installation |
| `GITHUB_API.md` | GitHub App auth, API endpoints, polling strategy, webhook option |
| `VM_LIFECYCLE.md` | Virtualization.framework usage, APFS cloning, base image creation |
| `CONTAINER_LIFECYCLE.md` | Apple Containerization framework, Linux container job flow |
| `JOB_SCHEDULER.md` | Job state machine, concurrency model, error handling |
| `CONFIGURATION.md` | Config schema, YAML spec, validation |
| `LOGGING.md` | swift-log setup, log format spec, rotation |
| `PROJECT_STRUCTURE.md` | Swift package layout, targets, dependencies |
| `SCHEMA.md` | All data models, Swift structs/enums, persistence |
| `OPEN_QUESTIONS.md` | Unresolved decisions the agent should surface before implementing |

## Project context

This project has been designed through an extended design session. All major architectural decisions have been made and are documented. The agent's job is to implement, not redesign. If something feels wrong, surface it via `OPEN_QUESTIONS.md` before proceeding.

## Core constraints

- Swift only. No Ruby, Python, or shell scripts in the main codebase.
- No external dependencies beyond what is listed in `PROJECT_STRUCTURE.md`.
- Raw SQL over ORM. GRDB is the approved database library if persistence is needed.
- No Tart. No Cilicon. No OCI image registries for macOS VMs.
- Virtualization.framework directly for macOS VMs.
- Apple Containerization framework directly for Linux containers.
- The orchestrator is a headless daemon — no UI, no HTTP server.

## The one-sentence pitch

Replace Cilicon's hundreds-of-GB OCI image approach with a single lean macOS base image built from IPSW, APFS-cloned per job, running `actions/runner --ephemeral` for true clean-state CI at a fraction of the disk cost.
